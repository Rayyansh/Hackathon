from django.db import models

# Create your models here.
# submissions/models.py


class Hackathon(models.Model):
    title = models.CharField(max_length=100)
    description = models.TextField()
    background_image = models.ImageField(upload_to='hackathon_images/')
    hackathon_image = models.ImageField(upload_to='hackathon_images/')
    submission_type_choices = (
        ('image', 'Image'),
        ('file', 'File'),
        ('link', 'Link'),
    )
    submission_type = models.CharField(max_length=5, choices=submission_type_choices)
    start_datetime = models.DateTimeField()
    end_datetime = models.DateTimeField()
    reward_prize = models.CharField(max_length=100)

class Submission(models.Model):
    hackathon = models.ForeignKey(Hackathon, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)
    summary = models.TextField()
    submission = models.FileField(upload_to='submissions/')
