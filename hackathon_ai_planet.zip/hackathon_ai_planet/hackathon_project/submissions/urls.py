# submissions/urls.py

from django.urls import path
from . import views

urlpatterns = [
    path('create/', views.create_hackathon),
    path('list/', views.list_hackathons),
    path('enroll/<int:hackathon_id>/', views.enroll_hackathon),
    path('submit/<int:hackathon_id>/', views.submit_project),
]
