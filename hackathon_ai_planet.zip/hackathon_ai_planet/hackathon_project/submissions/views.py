# submissions/views.py

from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response
from .models import Hackathon, Submission
from .serializers import HackathonSerializer, SubmissionSerializer
from rest_framework.parsers import MultiPartParser


@api_view(['POST'])
def create_hackathon(request):
    parser_classes = [MultiPartParser]  # Add the MultiPartParser here

    serializer = HackathonSerializer(data=request.data, context={'request': request}, parser_classes=parser_classes)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['GET'])
def list_hackathons(request):
    hackathons = Hackathon.objects.all()
    serializer = HackathonSerializer(hackathons, many=True)
    return Response(serializer.data)

@api_view(['POST'])
def enroll_hackathon(request, hackathon_id):
    try:
        hackathon = Hackathon.objects.get(pk=hackathon_id)
    except Hackathon.DoesNotExist:
        return Response({"error": "Hackathon not found"}, status=status.HTTP_404_NOT_FOUND)
    
    user = request.user
    # Check if the user is already enrolled in the hackathon
    if hackathon.users.filter(id=user.id).exists():
        return Response({"message": "User is already enrolled in the hackathon"}, status=status.HTTP_400_BAD_REQUEST)

    # If not, enroll the user in the hackathon
    hackathon.users.add(user)

    # Retrieve all the hackathons the user is enrolled in
    enrolled_hackathons = Hackathon.objects.filter(users=user)

    # Retrieve all the submissions of the user in the enrolled hackathon
    user_submissions = Submission.objects.filter(hackathon=hackathon, user=user)

    # Serialize the data and return the response
    enrolled_hackathons_serializer = HackathonSerializer(enrolled_hackathons, many=True)
    user_submissions_serializer = SubmissionSerializer(user_submissions, many=True)

    return Response({"enrolled_hackathons": enrolled_hackathons_serializer.data,
                     "user_submissions": user_submissions_serializer.data},
                    status=status.HTTP_200_OK)

@api_view(['POST'])
def submit_project(request, hackathon_id):
    try:
        hackathon = Hackathon.objects.get(pk=hackathon_id)
    except Hackathon.DoesNotExist:
        return Response({"error": "Hackathon not found"}, status=status.HTTP_404_NOT_FOUND)

    serializer = SubmissionSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save(hackathon=hackathon)
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
