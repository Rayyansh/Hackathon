from django.contrib import admin
from .models import Hackathon, Submission

# Register the Hackathon model
admin.site.register(Hackathon)

# Register the Submission model
admin.site.register(Submission)
